<?php
session_start();
include 'db_connect.php';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['student_id'];
    $station = $_POST['student_stt'];
    $status = $_POST['status'];
    do {
        for ($i = 0; $i < count($id); $i++) {
            $sql = "INSERT INTO attendance (att_id,std_id,sti_id,att_attend,att_date) VALUES ";
            $sql .= "(null,'{$id[$i]}', '{$station[$i]}', '{$status[$i]}', current_timestamp())";
            $result = $mysqli->query($sql);

            if (!$result) {
                $_SESSION['errormessage'] = "Invalid query " . $mysqli->error;
                break;
            }
        }
        $user = "";
        $station  = "";
        $_SESSION['successmessage'] = "Successful";
        header("location: /CCJE_Monitoring_System/team_leader/attendance.php");
        exit;
    } while (false);
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <?php include 'head.php' ?>
    <title>Attendance</title>
</head>

<body class="sb-nav-fixed">
    <?php include 'header.php' ?>
    <div id="layoutSidenav">
        <?php include 'nav.php' ?>
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <div class="container-fluid bg-white px-4 mb-2">
                        <div class="card bg-white mb-2">
                            <div class="card-body">
                                <div class="align-self-center">
                                    <h1 class="mt-1 ">Student List</h1>
                                    <ol class="breadcrumb mb-4">
                                        <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
                                        <li class="breadcrumb-item active">Tables</li>
                                    </ol>
                                </div>
                            </div>
                        </div>
                        <?php
                        
                        if (isset($_SESSION['successmessage'])) {
                        ?>
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <strong>Successful</strong> 
                                <button type="button" class="btn-close btn-sm" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        <?php

                            unset($_SESSION['successmessage']);
                        }
                        ?>
                        <?php
                        
                        if (isset($_SESSION['errormessage'])) {
                        ?>
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <strong>Error:</strong> <?php echo $_SESSION['errormessage']; ?>
                                <button type="button" class="btn-close btn-sm" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        <?php

                            unset($_SESSION['errormessage']);
                        }
                        ?>
                        
                        <div class="card mb-4">
                            <div class="card-header">
                                <i class="fas fa-table me-1"></i>
                                Attendance for <?php echo date("Y/m/d") ?> date
                            </div>
                            <div class="card-body">
                                <table class="table table-striped">
                                    <thead class="thead-dark">
                                        <tr>
                                            <th class=""><label for="student_id">Student ID</label></th>
                                            <th class="">Full Name</th>
                                            <th class=""><label for="status">Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <form action="attendance.php" method="post">
                                            <?php
                                            include 'db_connect.php';
                                            if ($mysqli->connect_errno) {
                                                die("Connection error: " . $mysqli->connect_error);
                                            }
                                            $stt = $_SESSION["userstation"];
                                            $sql = "SELECT * from student_station INNER JOIN student_infomation ON student_station.s_id=student_infomation.id where student_station.sti_id=$stt";
                                            $result = $mysqli->query($sql);
                                            if (!$result) {
                                                die("Invalid query: " . $mysqli->error);
                                            }
                                            while ($row = $result->fetch_assoc()) {
                                            ?>
                                                <tr>
                                                    <th class=""><?php echo $row['id'] ?><input type="hidden" name="student_id[]" id="student_id" value="<?php echo $row['id'] ?>">
                                                        <input type="hidden" name="student_stt[]" id="student_stt" value="<?php echo $stt ?>"></label>
                                                    </th>
                                                    <th class=""><?php echo $row['surname'] . ", " .  $row['firstname'] . " " .  $row['middlename'] . " " .  $row['suffixname'] ?></th>
                                                    <th class="mx-2"><input class="form-check-input mx-2" type="checkbox" name="status[]" value="present">Present
                                                        <input class="form-check-input mx-2" type="checkbox" name="status[]" value="late">Late
                                                        <input class="form-check-input mx-2" type="checkbox" name="status[]" value="absent">Absent
                                                    </th>
                                                </tr>
                                            <?php } ?>
                                            <div class="d-grid gap-2 d-md-block">
                                                <a class="btn btn-primary btn-sm" role="button" data-toggle="modal" data-target="#attendanceModal"><i class="bi bi-card-checklist"></i> Submit</a>
                                            </div>
                                            <div class="modal fade" id="attendanceModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                <div class="modal-dialog " role="document">
                                                    <div class="modal-content ">
                                                        <div class="modal-header bg-warning">
                                                            <h5 class="modal-title " id="exampleModalLabel"><i class="bi bi-exclamation-triangle-fill"></i> Are you sure</h5>
                                                            <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">
                                                            Do you want to submit the form?
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Close</button>
                                                            <input type="submit" value="Submit" class="btn btn-primary btn-sm"></input>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </form>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
            <?php include 'footer.php' ?>
        </div>


        <?php include 'script.php' ?>
</body>

</html>