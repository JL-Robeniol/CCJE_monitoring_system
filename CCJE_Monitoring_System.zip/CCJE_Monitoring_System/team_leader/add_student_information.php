<?php
session_start();

include 'db_connect.php';
$errorMessage = "";
$successMessage = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $studentid = $_SESSION["user"];
    $studentsurname = $_POST["student_surname"];
    $studentfirstname = $_POST["student_firstname"];
    $studentmiddlename = $_POST["student_middlename"];
    $studentsuffix = $_POST["student_extensionname"];
    $studentbirthday = $_POST["student_birthday"];
    $studentsex = $_POST["student_sex"];
    $studentcivilstatus = $_POST["student_civil_status"];
    $studentcitizenship = $_POST["student_citizenship"];
    $studentbloodtype = $_POST["student_blood_type"];
    $studentheight = $_POST["student_height"];
    $studentweight = $_POST["student_weight"];
    $studenttelno = $_POST["student_tel_no"];
    $studentmobileno = $_POST["student_mobile_no"];
    $studentemail = $_POST["student_email"];
    $studentgsisno = $_POST["student_gsis_no"];
    $studentpagibigno = $_POST["student_pagibig_no"];
    $studentphilhealthno = $_POST["student_philhealth_no"];
    $studentisssno = $_POST["student_sss_no"];
    $studentemployeeno = $_POST["student_employee_no"];

    $studentbopprovince = $_POST["student_bop_province"];
    $studentbopmunicipal = $_POST["student_bop_municipal"];
    $studentbopbarangay = $_POST["student_bop_barangay"];
    $studentraprovince = $_POST["student_ra_province"];
    $studentramunicipal = $_POST["student_ra_municipal"];
    $studentrabarangay = $_POST["student_ra_barangay"];
    $studentravillage = $_POST["student_ra_village"];
    $studentrastreet = $_POST["student_ra_street"];
    $studentrahouseno = $_POST["student_ra_house_no"];
    $studentrazipcode = $_POST["student_ra_zipcode"];
    $studentpaprovince = $_POST["student_pa_province"];
    $studentpamunicipal = $_POST["student_pa_municipal"];
    $studentpabarangay = $_POST["student_pa_barangay"];
    $studentpavillage = $_POST["student_pa_village"];
    $studentpastreet = $_POST["student_pa_street"];
    $studentpahouseno = $_POST["student_pa_house_no"];
    $studentpazipcode = $_POST["student_pa_zipcode"];

    $spousesurname = $_POST["fb_si_surname"];
    $spousefirstname = $_POST["fb_si_firstname"];
    $spousemiddlename = $_POST["fb_si_middlename"];
    $spouserxtensionname = $_POST["fb_si_rxtensionname"];
    $spouseoccupation = $_POST["fb_si_occupation"];
    $spouseemployername = $_POST["fb_si_employer_name"];
    $spousebusinessadd = $_POST["fb_si_business_add"];
    $spousetelno = $_POST["fb_si_tel_no"];
    $spousemobileno = $_POST["fb_si_mobile_no"];
    $fathersurname = $_POST["fb_pi_f_surname"];
    $fatherfirstname = $_POST["fb_pi_f_firstname"];
    $fathermiddlename = $_POST["fb_pi_f_middlename"];
    $fatherextensionname = $_POST["fb_pi_f_extensionname"];
    $fatheroccupation = $_POST["fb_pi_f_occupation"];
    $fathermobileno = $_POST["fb_pi_f_mobile_no"];
    $mothersurname = $_POST["fb_pi_m_surname"];
    $motherfirstname = $_POST["fb_pi_m_firstname"];
    $mothermiddlename = $_POST["fb_pi_m_middlename"];
    $mothermaidenname = $_POST["fb_pi_m_maidenname"];
    $motheroccupation = $_POST["fb_pi_m_occupation"];
    $mothermobileno = $_POST["fb_pi_m_mobile_no"];

    $elem = $_POST["eb_elem_school"];
    $elempoa = $_POST["eb_elem_school_poa"];
    $second = $_POST["eb_sec_school"];
    $secondpoa = $_POST["eb_sec_school_poa"];
    $course = $_POST["eb_cource_school"];
    $coursepoa = $_POST["eb_cource_school_poa"];
    $college = $_POST["eb_college"];
    $collegepoa = $_POST["eb_college_poa"];

    do {
        $sql = "INSERT INTO student_infomation ( id, surname, firstname, middlename, suffixname, birthday, sex, civil_status, citizenship, blood_type, height, weight, tel_no, mobile_no, email, gsis_no, pagibig_no, philhealth_no, sss_no, employee_no)" .
            "VALUE ('$studentid','$studentsurname', '$studentfirstname', '$studentmiddlename', '$studentsuffix', '$studentbirthday', '$studentsex', '$studentcivilstatus', '$studentcitizenship', '$studentbloodtype', '$studentheight', '$studentweight', '$studenttelno', '$studentmobileno', '$studentemail', '$studentgsisno', '$studentpagibigno', '$studentphilhealthno', '$studentisssno', '$studentemployeeno')";
        $sql2 = "INSERT INTO student_address_bg ( id, bop_province, bop_municipal, bop_barangay, ra_province, ra_municipal, ra_barangay, ra_village, ra_street, ra_house_no, ra_zipcode, pa_province, pa_municipal, pa_barangay, pa_village, pa_street, pa_house_no, pa_zipcode)" .
            "VALUE ('$studentid', '$studentbopprovince', '$studentbopmunicipal', '$studentbopbarangay', '$studentraprovince', '$studentramunicipal', '$studentrabarangay', '$studentravillage', '$studentrastreet', '$studentrahouseno', '$studentrazipcode', '$studentpaprovince', '$studentpamunicipal', '$studentpabarangay', '$studentpavillage', '$studentpastreet', '$studentpahouseno', '$studentpazipcode')";
        $sql3 = "INSERT INTO student_family_bg ( id, spouse_surname, spouse_firstname, spouse_middlename, spouse_suffixname, spouse_occupation, spouse_employer_name, spouse_business_address, spouse_tel_no, spouse_mobile_no, father_surname, father_firstname, father_middlename, father_suffixname, father_occupation, father_mobile_no, mother_surname, mother_firstname, mother_middlename, mother_maidenname, mother_occupation, mother_mobile_no)" .
            "VALUE ('$studentid','$spousesurname', '$spousefirstname','$spousemiddlename', '$spouserxtensionname','$spouseoccupation', '$spouseemployername','$spousebusinessadd', '$spousetelno','$spousemobileno', '$fathersurname','$fatherfirstname', '$fathermiddlename','$fatherextensionname', '$fatheroccupation','$fathermobileno', '$mothersurname','$motherfirstname', '$mothermiddlename','$mothermaidenname', '$motheroccupation','$mothermobileno')";
        $sql4 = "INSERT INTO student_education_bg (id, elemtary_school, elemtary_school_poa, secondary_school, secondary_school_poa, course_school, course_school_poa, college, college_poa)" .
            "VALUE ('$studentid', '$elem', '$elempoa', '$second', '$secondpoa', '$course', '$coursepoa', '$college', '$collegepoa')";
        $result = $mysqli->query($sql);
        $result2 = $mysqli->query($sql2);
        $result3 = $mysqli->query($sql3);
        $result4 = $mysqli->query($sql4);
        if (!$result || !$result2 || !$result3 || !$result4) {
            $errorMessage = "Invalid query " . $mysqli->error;
            break;
        }
        $studentid = 
        $studentsurname =
        $studentfirstname = 
        $studentmiddlename =
        $studentsuffix =
        $studentbirthday = 
        $studentsex = 
        $studentcivilstatus = 
        $studentcitizenship = 
        $studentbloodtype =
        $studentheight = 
        $studentweight = 
        $studenttelno =
        $studentmobileno =
        $studentemail = 
        $studentgsisno =
        $studentpagibigno =
        $studentphilhealthno =
        $studentisssno = 
        $studentemployeeno = 

        $studentbopprovince = 
        $studentbopmunicipal =
        $studentbopbarangay =
        $studentraprovince = 
        $studentramunicipal = 
        $studentrabarangay = 
        $studentravillage =
        $studentrastreet = 
        $studentrahouseno = 
        $studentrazipcode = 
        $studentpaprovince = 
        $studentpamunicipal =
        $studentpabarangay = 
        $studentpavillage = 
        $studentpastreet = 
        $studentpahouseno = 
        $studentpazipcode =

        $spousesurname = 
        $spousefirstname = 
        $spousemiddlename = 
        $spouserxtensionname = 
        $spouseoccupation = 
        $spouseemployername =
        $spousebusinessadd = 
        $spousetelno = 
        $spousemobileno = 
        $fathersurname = 
        $fatherfirstname =
        $fathermiddlename = 
        $fatherextensionname = 
        $fatheroccupation = 
        $fathermobileno = 
        $mothersurname = 
        $motherfirstname = 
        $mothermiddlename =
        $mothermaidenname = 
        $motheroccupation = 
        $mothermobileno = 

        $elem = 
        $elempoa = 
        $second = 
        $secondpoa = 
        $course = 
        $coursepoa = 
        $college = 
        $collegepoa = "";
        
    } while (false);
    header("location: /CCJE_Monitoring_System/team_leader/index.php");
            exit;
}
