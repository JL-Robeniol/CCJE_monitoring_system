<?php

session_start();
include 'db_connect.php';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $station = $_POST["STI_Station"];
    $lname = $_POST["STI_Lname"];
    $mname = $_POST["STI_Mname"];
    $fname = $_POST["STI_Fname"];
    $sname = $_POST["STI_Sname"];
    $assign = $_POST["STI_Assign"];
    $email = $_POST["STI_Email"];
    $contact = $_POST["STI_Contact"];
    $barangay = $_POST["STI_Barangay"];
    $region = $_POST["STI_Region"];
    $municipal = $_POST["STI_Municipal"];


    do {

        if (
            empty($station) || empty($lname) || empty($fname) || empty($mname) || empty($sname) || empty($email)
            || empty($contact) || empty($barangay) || empty($assign) || empty($region) || empty($municipal)
        ) {

            $_SESSION['errormessage'] = "All the field are required";
            header("location: /CCJE_Monitoring_System/admin/station_info.php");
            exit;
            break;
        } else {


            $sql = "INSERT INTO station_info (sti_station,sti_lname,sti_fname,sti_mname,sti_sname,sti_assign_date,sti_email,sti_contact, sti_barangay,sti_municipal,sti_region)" .
                "VALUE ('$station','$lname', '$fname', '$mname', '$sname','$assign', '$email', '$contact','$barangay','$municipal','$region')";

            $result = $mysqli->query($sql);

            if (!$result) {
                $_SESSION['errormessage'] = "Invalid query " . $mysqli->error;
                header("location: /CCJE_Monitoring_System/admin/station_info.php");
                exit;
                break;
            }
            $station = "";
            $fname = "";
            $lname = "";
            $mname = "";
            $sname = "";
            $assign = "";
            $contact = "";
            $email = "";
            $barangay = "";
            $municipal = "";
            $region = "";
            $_SESSION['successmessage'] = "Successful added new Station Information";

            header("location: /CCJE_Monitoring_System/admin/station_info.php");
            exit;
        }
    } while (false);
}
