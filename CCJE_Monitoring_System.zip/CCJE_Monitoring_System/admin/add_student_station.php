<?php

session_start();
include 'db_connect.php';

$errorMessage = "";
$successMessage = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $user = $_POST["user_id"];
    $station = $_POST["station_id"];
    do {

        if (empty($user) || empty($station)) {

            $errorMessage = "All the field are required";
            break;
        } else {


            $sql = "INSERT INTO student_station (id,s_id,sti_id)" .
                "VALUE ( NULL,'$user','$station')";

            $result = $mysqli->query($sql);

            if (!$result) {
                $errorMessage = "Invalid query " . $mysqli->error;
                break;
            }
            $user = "";
            $station  = "";
            $successMessage = "Successful send Message";
            header("location: /CCJE_Monitoring_System/admin/student_station_assign.php");
            exit;
        }
    } while (false);
}
?>