<?php
session_start();
$id = $_SESSION['delete_s_id'];
include 'db_connect.php';
$sql = "DELETE from student_db where s_id=$id";
$mysqli->query($sql);

header("location: /CCJE_Monitoring_System/admin/student_table.php");
exit;
?>