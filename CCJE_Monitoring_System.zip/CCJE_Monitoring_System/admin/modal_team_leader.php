<!-- Delete -->
<div class="modal fade" id="delete_<?php echo $row['id']; ?>" tabindex="-1" aria-labelledby="ModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-danger">
                <h5 class="modal-title " id="ModalLabel">Delete Team Leader</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p class="text-center">Are you sure you want to Delete?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary  btn-sm" data-bs-dismiss="modal">Close</button>
                <a href="delete_team_leader.php?id=<?php echo $row['id']; ?>" class="btn btn-danger  btn-sm"> Yes</a>
            </div>
        </div>
    </div>
</div>


<!-- Edit -->
<div class="modal fade" id="edit_<?php echo $row['id']; ?>" tabindex="-1" aria-labelledby="ModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="ModalLabel">Edit Admin</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form method="POST" action="edit_team_leader.php?id=<?php echo $row['id']; ?>">
                    <div class="row clearfix">
                        <div class="col-md-12 col-sm-12">
                            <div class="form-group">
                                <label class="mb-3">ID - Student name</label>
                                <select name="user_id" class="form-control custom-select mb-3">
                                    <option class="align-center" value="<?php echo $row['id']; ?>"><?php echo $row['id'] . " - " . $row['surname'] . ", " . $row['firstname'] . " " . $row['middlename'] . " " . $row['suffixname']; ?></option>
                                    <?php
                                    include 'db_connect.php';
                                    $sql3 = "SELECT * from student_infomation ";
                                    $result3 = $mysqli->query($sql3);
                                    if (!$result3) {
                                        die("Invalid query: " . $mysqli->error);
                                    }
                                    while ($row3 = $result3->fetch_assoc()) {
                                    ?>

                                        <option value='<?php echo $row3['id']; ?>'><?php echo $row3['id'] . " - " . $row3['surname'] . ", " . $row3['firstname'] . " " . $row3['middlename'] . " " . $row3['suffixname']; ?></option>

                                    <?php
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-12 col-sm-12">
                            <div class="form-group">
                                <label class="mb-3">Station Designated</label>
                                <select name="station_id" class="form-control custom-select mb-3">
                                    <option class="align-center" value="<?php echo $row['sti_id']; ?>"><?php echo $row['sti_station']  . " - " . $row['sti_lname'] . ", " .  $row['sti_fname'] . " " . $row['sti_mname'] . " " . $row['sti_sname']  . " - " . $row['sti_region'] . ", " . $row['sti_municipal'] . ", " . $row['sti_barangay']; ?></option>
                                    <?php
                                    include 'db_connect.php';
                                    $sql2 = "SELECT * from station_info ";
                                    $result2 = $mysqli->query($sql2);
                                    if (!$result2) {
                                        die("Invalid query: " . $mysqli->error);
                                    }
                                    while ($row2 = $result2->fetch_assoc()) {
                                    ?>

                                        <option value="<?php echo $row2['sti_id']; ?>"> <?php echo $row2['sti_station']  . " - " . $row2['sti_lname'] . ", " .  $row2['sti_fname'] . " " . $row2['sti_mname'] . " " . $row2['sti_sname']  . " - " . $row2['sti_region'] . ", " . $row2['sti_municipal'] . ", " . $row2['sti_barangay']; ?></option>
                                    <?php
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                        <br>
                        <div class="col-sm-12 mb-3">
                            <button type="submit" class="btn btn-primary">Submit</button>
                            <a href="team_leader_table.php" class="btn btn-outline-secondary" title="">Cancel</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>