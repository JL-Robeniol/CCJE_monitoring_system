<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <?php include 'head.php' ?>
    <title>Dashboard</title>
</head>

<body class="sb-nav-fixed">
    <?php include 'header.php' ?>
    <div id="layoutSidenav">
        <?php include 'nav.php' ?>
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <div class="card bg-white mb-2">
                        <div class="card-body">
                            <div class="align-self-center">
                                <h1 class="mt-1 ">Dashboard</h1>
                                <ol class="breadcrumb mb-2">
                                    <li class="breadcrumb-item active">Dashboard</li>
                                </ol>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xl-4 col-md-2">
                            <div class="card bg-primary text-white mb-2 border border-secondary">
                                <div class="card-body rounded">
                                    <div class="align-self-center">
                                        <i class="fa fa-user text-white fa-2x me-4"></i>
                                    </div>
                                    <div>
                                        <h6>STUDENT ENROLLED</h6>
                                        <?php
                                        include 'db_connect.php';
                                        $sql = "SELECT * from student_enroll";
                                        $result = $mysqli->query($sql);
                                        $count = mysqli_num_rows($result);
                                        if (!$result) {
                                            die("Invalid query: " . $mysqli->error);
                                        }
                                        echo "<h4 class='mb-0'>$count</h4>";
                                        ?>
                                    </div>
                                </div>
                                <div class="card-footer d-flex align-items-center justify-content-between">
                                    <a class="small text-black stretched-link" href="student_table.php">View Details</a>
                                    <div class="small text-black"><i class="fas fa-angle-right"></i></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 col-md-2">
                            <div class="card bg-warning text-black mb-2 border border-secondary">
                                <div class="card-body rounded">
                                    <div class="align-self-center">
                                        <i class="fa fa-users text-black fa-2x me-4"></i>
                                    </div>
                                    <div>
                                        <h6> TEAM LEADERS</h6>
                                        <?php
                                        include 'db_connect.php';
                                        $sql = "SELECT * from team_leader_student";
                                        $result = $mysqli->query($sql);
                                        $count = mysqli_num_rows($result);
                                        if (!$result) {
                                            die("Invalid query: " . $mysqli->error);
                                        }
                                        echo "<h4 class='mb-0'>$count</h4>";
                                        ?>
                                    </div>
                                </div>
                                <div class="card-footer d-flex align-items-center justify-content-between">
                                    <a class="small text-black stretched-link" href="team_leader_table.php">View Details</a>
                                    <div class="small text-black"><i class="fas fa-angle-right"></i></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 col-md-2">
                            <div class="card bg-danger text-white mb-2 border border-secondary">
                                <div class="card-body rounded">
                                    <div class="align-self-center">
                                        <i class="fa fa-building text-white fa-2x me-4"></i>
                                    </div>
                                    <div>
                                        <h6>STATION</h6>
                                        <?php
                                        include 'db_connect.php';
                                        $sql = "SELECT * from station_info";
                                        $result = $mysqli->query($sql);
                                        $count = mysqli_num_rows($result);
                                        if (!$result) {
                                            die("Invalid query: " . $mysqli->error);
                                        }
                                        echo "<h4 class='mb-0'>$count</h4>";
                                        ?>
                                    </div>
                                </div>
                                <div class="card-footer d-flex align-items-center justify-content-between">
                                    <a class="small text-black stretched-link" href="station_info.php">View Details</a>
                                    <div class="small text-black"><i class="fas fa-angle-right"></i></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="align-middle row">
                        <div class="col-xl-6 col-md-1">
                            <div class="d-flex justify-content-center container-fluid px-4">
                                <div class="col-md-12">
                                    <div class="row">
                                        <div class=" col-md-12">
                                            <div class="card bg-black text-white mb-4">
                                                <div class="card-body">
                                                    <div class="align-self-center">
                                                        <div>
                                                            <h4>Bulliten Board</h4>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php
                                            include 'db_connect.php';
                                            if ($mysqli->connect_errno) {
                                                die("Connection error: " . $mysqli->connect_error);
                                            }
                                            $result = $mysqli->query("SELECT * FROM post_db ORDER BY post_id DESC");
                                            if (!$result) {
                                                die("Invalid query: " . $mysqli->error);
                                            }
                                            while ($row = $result->fetch_assoc()) {
                                                $img = $row['post_image'];
                                                $last_updated = $row["post_date_time"];
                                                $date = date("F d Y H:i:s.", strtotime($last_updated));
                                            ?>
                                                <div class="card mb-3">

                                                    <div class="card-body">
                                                        <h5 class="card-title">Announcement</h5>
                                                        <p class="card-text"><?php echo $row['post_content']; ?></p>
                                                        <p class="card-text"><small class="text-muted"><?php echo $date; ?></small></p>
                                                    </div>
                                                    <img src="../admin/<?php echo $img ?>" class="card-img-top" alt="...">
                                                </div>
                                            <?php
                                            }
                                            ?>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-6">
                            <div class="card mb-4 border border-dark">
                                <div class="card-header">
                                    <i class="fas fa-chart-bar me-1"></i>
                                    Bar Chart Report
                                </div>
                                <div class="card-body"><canvas id="bar-chart" width="100%" height="80%"></canvas></canvas></div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
            <?php include 'footer.php' ?>
        </div>
    </div>
    <?php include 'script.php' ?>
</body>

</html>