<?php

session_start();
include 'db_connect.php';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $stdid = $_POST["studentid"];
    $lname = $_POST["lastname"];
    $fname = $_POST["firstname"];
    $mname = $_POST["middlename"];
    $sname = $_POST["suffixname"];
    $block = $_POST["block"];
    $year = $_POST["year"];
    $password = $_POST["password"];
    $id = $_GET['id'];

    do {

        if (empty($stdid) || empty($lname) || empty($fname) || empty($mname) || empty($sname) || empty($block) || empty($year) || empty($password)) {

            $_SESSION['errormessage'] = "All the field are required";
            break;
        } else {
            $sql = "UPDATE student_enroll SET id='$stdid', last_name='$lname', first_name='$fname', middle_name='$mname', suffix_name='$sname', password='$password', 	block='$block', school_year='$year' WHERE id = '$id';" ;
            $result = $mysqli->query($sql);

            if (!$result) {
                $_SESSION['errormessage'] = "Invalid query " . $mysqli->error;
                break;
            }
            $stdid = "";
            $lname = "";
            $fname = "";
            $mname = "";
            $sname = "";
            $block = "";
            $year = "";
            $password = "";
            $_SESSION['successmessage'] = "Successful";
            header("location: /CCJE_Monitoring_System/admin/student_enrolled.php");
            exit;
        }
    } while (false);
}
