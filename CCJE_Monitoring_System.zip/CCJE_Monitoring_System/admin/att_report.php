<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <?php include 'head.php' ?>
    <title>Attendance</title>
</head>

<body class="sb-nav-fixed">
    <?php include 'header.php' ?>
    <div id="layoutSidenav">
        <?php include 'nav.php' ?>
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <div class="card bg-white mb-2">
                        <div class="card-body">
                            <div class="align-self-center">
                                <h1 class="mt-4">Attendance</h1>
                                <ol class="breadcrumb mb-4">
                                    <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
                                    <li class="breadcrumb-item active">Tables</li>
                                </ol>
                                <?php 
                                
                                ?>
                            </div>
                        </div>
                    </div>
                    <div class="card mb-4">
                        <div class="card-header">
                            <i class="fas fa-message me-1"></i>
                            Attendance table
                        </div>
                        <div class="card-body">
                            <table class="table table-bordered" id="datatablesSimple">
                                <thead>
                                    <tr>
                                        <th class="cell">Student ID</th>
                                        <th class="cell">Fullname</th>
                                        <th class="cell">Station</th>
                                        <th class="cell">Status</th>
                                        <th class="cell">Date</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    include 'db_connect.php';
                                    $sql = "SELECT * FROM attendance JOIN student_infomation on attendance.std_id=student_infomation.id JOIN station_info on attendance.sti_id=station_info.sti_id;";
                                    $result = $mysqli->query($sql);
                                    if (!$result) {
                                        die("Invalid query: " . $mysqli->error);
                                    }
                                    while ($row = $result->fetch_assoc()) {
                                    ?>

                                        <tr>
                                            <td><?php echo $row['std_id']; ?></td>
                                            <td><?php echo $row['surname'] . ", " . $row['firstname'] . " " . $row['middlename'] . " " . $row['suffixname']; ?></td>
                                            <td><?php echo $row['sti_station'] . " - " .$row['sti_barangay'] . ", " . $row['sti_municipal'] . ", " . $row['sti_region']; ?></td>
                                            <td><?php echo $row['att_attend']; ?></td>
                                            <td><?php echo $row['att_date']; ?></td>
                                        </tr>
                                    <?php
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
    <?php include 'script.php' ?>
</body>

</html>