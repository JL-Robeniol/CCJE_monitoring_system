<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <?php include 'head.php' ?>
    <title>Submission Report</title>
</head>

<body class="sb-nav-fixed">
    <?php include 'header.php' ?>
    <div id="layoutSidenav">
        <?php include 'nav.php' ?>
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <div class="card bg-white mb-2">
                        <div class="card-body">
                            <div class="align-self-center">
                                <h1 class="mt-4">Submission Report</h1>
                                </h1>
                                <ol class="breadcrumb mb-4">
                                    <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
                                    <li class="breadcrumb-item active">Tables</li>
                                </ol>
                            </div>
                        </div>
                    </div>
                    <?php

                    if (isset($_SESSION['successmessage'])) {
                    ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <strong>Successful</strong>
                            <button type="button" class="btn-close btn-sm" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php

                        unset($_SESSION['successmessage']);
                    }
                    ?>
                    <?php

                    if (isset($_SESSION['errormessage'])) {
                    ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <strong>Error:</strong> <?php echo $_SESSION['errormessage']; ?>
                            <button type="button" class="btn-close btn-sm" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php

                        unset($_SESSION['errormessage']);
                    }
                    ?>
                    <div class="card">
                        <div class="card-header">
                        Submission Report
                        </div>
                        <div class="card-body">
                            <form method="POST" action="report.php">
                                <div class="row clearfix">
                                    <div class="col-md-4 col-sm-12">
                                        <div class="form-group">
                                            <label class="mb-3">ID - Student Name</label>
                                            <select name="stationid" class="form-control custom-select mb-3">
                                                <option value="" disabled selected></option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-12">
                                        <div class="form-group">
                                            <label class="mb-3">Submitted</label>
                                            <select name="status" class="form-control custom-select mb-3">
                                                <option value="" disabled selected></option>
                                                <option value="">Parent Consent</option>
                                                <option value="">PhilHealth ID</option>
                                                <option value="">Certification of Vaccination</option>
                                                <option value="">Pregnancy Test</option>
                                            </select>
                                        </div>
                                    </div>
                                    <br>
                                    <div class="col-sm-12 mb-3">
                                        <button type="submit" class="btn btn-primary btn-sm">Go</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
    <?php include 'script.php' ?>
</body>

</html>