<?php
session_start();
include 'db_connect.php';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $station = $_POST["stationid"];
    $status = $_POST["status"];
    $date = $_POST["date"];
    $newdate = date("Y-m-d", strtotime($date));
    do {
            $sql = "SELECT * FROM attendance JOIN student_infomation ON student_infomation.id=attendance.std_id JOIN station_info on station_info.sti_id=attendance.sti_id WHERE attendance.sti_id=$station and attendance.att_attend='$status' and attendance.att_date=$newdate;";
            $result = $mysqli->query($sql);
            if (!$result) {
                $_SESSION['errormessage'] = "Invalid query " . $mysqli->error;
                header("location: /CCJE_Monitoring_System/admin/report.php");
                break;
            }
            while ($row = $result->fetch_assoc()) {
                $_SESSION['attreport'] = "
                                            <td>$row[id]</td>
                                            <td>$row[surname], $row[firstname] $row[middlename]  $row[suffixname]</td>
                                            <td>$row[sti_id] - $row[sti_station], $row[sti_barangay], $row[sti_municipal], $row[sti_region]</td>
                                            <td>$row[att_attend]</td>
                                            <td>$row[att_date]</td>
                ";
            }
            $_SESSION['successmessage'] = "Successful";
            header("location: /CCJE_Monitoring_System/admin/report.php");
            exit;
        
    } while (false);
}
?>