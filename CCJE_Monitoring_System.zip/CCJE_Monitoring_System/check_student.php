<?php
session_start();

$host = "localhost";
$dbname = "ccje_db";
$username = "root";
$password = "";

$mysqli = new mysqli($host, $username, $password, $dbname);

if ($mysqli->connect_errno) {
    die("Connection error: " . $mysqli->connect_error);

}
$user=$_SESSION["user"];

$sql = "SELECT * from student_infomation Where id=$user";
if ($result = $mysqli->query($sql))
while ($row = $result->fetch_assoc()) {
    $id=$row['id'];
}

if($user === $id){
    header("location: /CCJE_Monitoring_System/student/index.php");
}else{
    header("location: /CCJE_Monitoring_System/student/form.php");
}


?>