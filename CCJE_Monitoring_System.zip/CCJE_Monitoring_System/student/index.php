<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <?php include 'head.php' ?>
    <title>Dashboard</title>
</head>

<body class="sb-nav-fixed">
    <?php include 'header.php' ?>
    <div id="layoutSidenav">
        <?php include 'nav.php' ?>
        <div id="layoutSidenav_content">
            <div id="layoutAuthentication">
                <div id="layoutAuthentication_content">
                    <main>
                        <div class="d-flex justify-content-center container-fluid px-4">
                            <div class="col-md-12">
                                <div class="row">
                                    <div class=" col-md-12">
                                        <div class="card bg-black text-white mb-4">
                                            <div class="card-body">
                                                <div class="align-self-center">
                                                    <div>
                                                        <h4>Bulliten Board</h4>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php
                                        include 'db_connect.php';
                                        if ($mysqli->connect_errno) {
                                            die("Connection error: " . $mysqli->connect_error);
                                        }
                                        $result = $mysqli->query("SELECT * FROM post_db ORDER BY post_id DESC");
                                        if (!$result) {
                                            die("Invalid query: " . $mysqli->error);
                                        }
                                        while ($row = $result->fetch_assoc()) {
                                            $img = $row['post_image'];
                                            $last_updated = $row["post_date_time"];
                                            $date = date("F d Y H:i:s.", strtotime($last_updated));
                                           ?>                                           
                                            <div class="card mb-3">
                                            
                                            <div class="card-body">
                                                <h5 class="card-title">Announcement</h5>
                                                <p class="card-text"><?php echo $row['post_content'];?></p>
                                                <p class="card-text"><small class="text-muted"><?php echo $date;?></small></p>
                                            </div>
                                            <img src="../admin/<?php echo $img?>" class="card-img-top" alt="...">
                                        </div>
                                        <?php 
                                        }
                                        ?>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </main>
                </div>
            </div>
        </div>
    </div>
    <?php include 'script.php' ?>
</body>

</html>