<?php
session_start();
include 'db_connect.php';

if (isset($_POST['submit'])) {
  // Check if both image files are present
  if (!empty($_FILES['image1']['name'])) {
    // Set the target directory where the images will be saved
    $target_dir = "../uploads/";

    // Get the filename and extension of each image file
    $image1_name = basename($_FILES["image1"]["name"]);
    $image1_ext = pathinfo($image1_name, PATHINFO_EXTENSION);

    // Generate a unique name for each image to prevent overwriting
    $image1_newname = uniqid('image1_', true) . "." . $image1_ext;

    // Set the target paths for each image file
    $target_file1 = $target_dir . $image1_newname;


    $allowTypes = array('jpg', 'png', 'jpeg', 'gif');
    if (in_array($image1_ext, $allowTypes)) {
      $image = $_FILES['image1']['tmp_name'];
      $image2 = $_FILES['image2']['tmp_name'];
      $stdid = $_SESSION["user"];

      // Insert image content into database 
      $insert = $mysqli->query("INSERT into cer_vac_db (std_id,image1) VALUES ('$stdid','$target_file1')");

      move_uploaded_file($_FILES['image1']['tmp_name'], "$target_file1");



      if ($insert) {
        $_SESSION['successmessage'] = 'success';
        header("location: /CCJE_Monitoring_System/student/requirements.php");
      } else {
        $_SESSION['errormessage'] = "File upload failed, please try again.";
      }
    } else {
      $_SESSION['errormessage'] = 'Sorry, only JPG, JPEG, PNG, & GIF files are allowed to upload.';
    }
  } else {
    $_SESSION['errormessage'] = 'Please select an image file to upload.';
  }
}
