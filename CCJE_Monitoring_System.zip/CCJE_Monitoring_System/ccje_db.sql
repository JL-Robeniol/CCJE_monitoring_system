-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 29, 2023 at 10:16 AM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ccje_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_db`
--

CREATE TABLE `admin_db` (
  `admin_id` int(11) NOT NULL,
  `admin_fname` varchar(250) NOT NULL,
  `admin_lname` varchar(250) NOT NULL,
  `admin_mname` varchar(250) NOT NULL,
  `admin_sname` varchar(20) NOT NULL,
  `admin_position` varchar(255) NOT NULL,
  `admin_email` varchar(255) NOT NULL,
  `admin_password` varchar(255) NOT NULL,
  `time/date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_db`
--

INSERT INTO `admin_db` (`admin_id`, `admin_fname`, `admin_lname`, `admin_mname`, `admin_sname`, `admin_position`, `admin_email`, `admin_password`, `time/date`) VALUES
(12345678, 'admin', 'admin', 'admin', ' ', 'ojt coordinator', 'admin@admin.com', '$2y$10$Tg7jSUbqTG1WQ5IXBkcy6OZ6jntp7C9RgZXdcp9KHg3VZY2TSkOsO', '2023-01-23 14:31:31'),
(98765432, 'admin2', 'admin2', 'admin2', ' ', ' admin2', 'admin2@admin.com', '$2y$10$NA7f8yMI0Mfa/JJHMaeA9O5nkTNFF/xfknetJF3F0wgGmJn9Gpl32', '2023-02-01 23:11:15');

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `att_id` int(11) NOT NULL,
  `std_id` int(11) NOT NULL,
  `sti_id` int(11) NOT NULL,
  `att_attend` varchar(20) NOT NULL,
  `att_date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`att_id`, `std_id`, `sti_id`, `att_attend`, `att_date`) VALUES
(4, 20220001, 2, 'present', '2023-04-16'),
(5, 20220004, 2, 'late', '2023-04-16'),
(6, 20220006, 2, 'absent', '2023-04-16'),
(7, 20220009, 2, 'present', '2023-04-16'),
(8, 20220001, 2, 'present', '2023-04-17'),
(9, 20220004, 2, 'present', '2023-04-17'),
(10, 20220006, 2, 'present', '2023-04-17'),
(11, 20220009, 2, 'absent', '2023-04-17'),
(20, 20220001, 2, 'present', '2023-04-25'),
(21, 20220004, 2, 'present', '2023-04-25'),
(22, 20220006, 2, 'present', '2023-04-25'),
(23, 20220009, 2, 'present', '2023-04-25'),
(24, 20220001, 2, 'present', '2023-04-29'),
(25, 20220004, 2, 'late', '2023-04-29'),
(26, 20220006, 2, 'present', '2023-04-29'),
(27, 20220009, 2, 'late', '2023-04-29');

-- --------------------------------------------------------

--
-- Table structure for table `cer_vac_db`
--

CREATE TABLE `cer_vac_db` (
  `id` int(10) NOT NULL,
  `std_id` int(10) NOT NULL,
  `image1` varchar(250) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cer_vac_db`
--

INSERT INTO `cer_vac_db` (`id`, `std_id`, `image1`, `date`) VALUES
(1, 20220001, '../uploads/image1_644677f40e1e14.27497692.jpg', '2023-04-24');

-- --------------------------------------------------------

--
-- Table structure for table `message_db`
--

CREATE TABLE `message_db` (
  `message_id` int(20) NOT NULL,
  `user_id` int(20) NOT NULL,
  `send_to_id` int(20) NOT NULL,
  `message_content` varchar(255) NOT NULL,
  `message_time_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `message_db`
--

INSERT INTO `message_db` (`message_id`, `user_id`, `send_to_id`, `message_content`, `message_time_date`) VALUES
(8, 20220001, 20220006, 'DO THIS 2 all of you', '2023-04-25 03:37:48'),
(9, 20220001, 12345678, 'i submit', '2023-04-25 04:01:52');

-- --------------------------------------------------------

--
-- Table structure for table `parent_con_db`
--

CREATE TABLE `parent_con_db` (
  `id` int(10) NOT NULL,
  `std_id` int(10) NOT NULL,
  `file1` varchar(250) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `parent_con_db`
--

INSERT INTO `parent_con_db` (`id`, `std_id`, `file1`, `date`) VALUES
(2, 20220001, '../uploads/Doc2 (2).docx', '2023-04-24');

-- --------------------------------------------------------

--
-- Table structure for table `philhealth_id_db`
--

CREATE TABLE `philhealth_id_db` (
  `id` int(11) NOT NULL,
  `std_id` int(11) NOT NULL,
  `image1` varchar(250) NOT NULL,
  `image2` varchar(250) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `philhealth_id_db`
--

INSERT INTO `philhealth_id_db` (`id`, `std_id`, `image1`, `image2`, `date`) VALUES
(3, 20220001, '../uploads/image1_64467416cb44c3.40030257.jpg', '../uploads/image2_64467416cb4584.52839055.jpg', '2023-04-24');

-- --------------------------------------------------------

--
-- Table structure for table `post_db`
--

CREATE TABLE `post_db` (
  `post_id` int(11) NOT NULL,
  `post_content` varchar(500) NOT NULL,
  `post_image` varchar(250) NOT NULL,
  `post_date_time` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `post_db`
--

INSERT INTO `post_db` (`post_id`, `post_content`, `post_image`, `post_date_time`) VALUES
(10, 'We are excited to welcome you to our onjob training program! This training is designed to provide you with hands-on experience and practical skills that will prepare you for your future career.', '../uploads/post1_64494fcfd4d540.99258207.jpg', '2023-04-27 00:22:39');

-- --------------------------------------------------------

--
-- Table structure for table `pregnancy_db`
--

CREATE TABLE `pregnancy_db` (
  `id` int(10) NOT NULL,
  `std_id` int(10) NOT NULL,
  `image1` varchar(250) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `station_info`
--

CREATE TABLE `station_info` (
  `sti_id` int(11) NOT NULL,
  `sti_station` varchar(50) NOT NULL,
  `sti_lname` varchar(255) NOT NULL,
  `sti_fname` varchar(255) NOT NULL,
  `sti_mname` varchar(255) NOT NULL,
  `sti_sname` varchar(255) NOT NULL,
  `sti_assign_date` varchar(20) NOT NULL,
  `sti_email` varchar(255) NOT NULL,
  `sti_contact` bigint(20) NOT NULL,
  `sti_barangay` varchar(255) NOT NULL,
  `sti_municipal` varchar(255) NOT NULL,
  `sti_region` varchar(255) NOT NULL,
  `time/date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `station_info`
--

INSERT INTO `station_info` (`sti_id`, `sti_station`, `sti_lname`, `sti_fname`, `sti_mname`, `sti_sname`, `sti_assign_date`, `sti_email`, `sti_contact`, `sti_barangay`, `sti_municipal`, `sti_region`, `time/date`) VALUES
(2, 'BFP', 'Juan', 'Carlo', 'Jacinto', ' ', '2022-06-09', 'juancarlo@email.com', 999999999, 'San Vicente', 'Urdaneta', 'Pangasinan', '2023-01-22 22:26:56'),
(3, 'PNP', 'Kendall', 'Sally', 'Moon', 'Jr', '2022-06-09', 'sallykendall@email.com', 999999999, 'Downtown', 'Baguio', ' Benguet', '2023-01-22 23:13:47'),
(11, 'BJMP', 'Velasco', 'John', 'S.', '', '06-09-2020', 'email@email.com', 9000000000, 'Poblacion', 'Laoac', 'Pangasinan', '2023-04-10 20:53:13'),
(12, 'Mall', 'Sison', 'Jonathan', 'P.', '', '06-09-2020', 'email@email.com', 9000000000, 'Milo St', 'Manaoag', 'Pangasinan', '2023-04-10 20:57:48'),
(13, 'PNP', 'Dela Rosa', 'Joshua', 'D.', '', '06-09-2020', 'email@email.com', 9000000000, 'Town Hall', 'Binalonan', 'Pangasinan', '2023-04-10 20:57:48');

-- --------------------------------------------------------

--
-- Table structure for table `student_address_bg`
--

CREATE TABLE `student_address_bg` (
  `id` int(10) NOT NULL,
  `bop_province` varchar(50) NOT NULL,
  `bop_municipal` varchar(50) NOT NULL,
  `bop_barangay` varchar(50) NOT NULL,
  `ra_province` varchar(50) NOT NULL,
  `ra_municipal` varchar(50) NOT NULL,
  `ra_barangay` varchar(50) NOT NULL,
  `ra_village` varchar(50) NOT NULL,
  `ra_street` varchar(50) NOT NULL,
  `ra_house_no` varchar(20) NOT NULL,
  `ra_zipcode` int(10) NOT NULL,
  `pa_province` varchar(50) NOT NULL,
  `pa_municipal` varchar(50) NOT NULL,
  `pa_barangay` varchar(50) NOT NULL,
  `pa_village` varchar(50) NOT NULL,
  `pa_street` varchar(20) NOT NULL,
  `pa_house_no` varchar(10) NOT NULL,
  `pa_zipcode` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_address_bg`
--

INSERT INTO `student_address_bg` (`id`, `bop_province`, `bop_municipal`, `bop_barangay`, `ra_province`, `ra_municipal`, `ra_barangay`, `ra_village`, `ra_street`, `ra_house_no`, `ra_zipcode`, `pa_province`, `pa_municipal`, `pa_barangay`, `pa_village`, `pa_street`, `pa_house_no`, `pa_zipcode`) VALUES
(20220001, 'Pangasinan', 'Urdaneta City', 'Paurido Street', 'Pangasinan', 'Urdaneta City', 'San Vicente', 'N/A', 'west', '01', 2428, 'Pangasinan', 'Urdaneta City', 'San Vicente', 'N/A', 'west', '01', 2428),
(20220002, 'Pangasinan', 'Manaoag', 'Poblacion', 'Pangasinan', 'Manaoag', 'Cabanbanan', 'N/A', 'Zone 5', '059', 2430, 'Pangasinan', 'Manaoag', 'Cabanbanan', 'N/A', 'Zone 5', '059', 2430),
(20220003, 'Pangasinan', 'Manaoag', 'Poblacion', 'Pangasinan', 'Manaoag', 'Pao', 'N/A', 'Zone 9', '09', 2430, 'Pangasinan', 'Manaoag', 'Pao', 'N/A', 'Zone 9', '09', 2430),
(20220004, 'Pangasinan', 'Urdaneta', 'Poblacion', 'Pangasinan', 'Urdaneta', 'Camanang', 'N/A', 'Zone 3', '102', 2428, 'Pangasinan', 'Urdaneta', 'Camanang', 'N/A', 'Zone 3', '102', 2428),
(20220005, 'Pangasinan', 'Binalonan', 'Poblacion', 'Pangasinan', 'Binalonan', 'Capas', 'N/A', 'Zone 4', '1106', 2436, 'Pangasinan', 'Binalonan', 'Capas', 'N/A', 'Zone 4', '1106', 2436),
(20220006, 'Pangasinan', 'Urdaneta', 'Poblacion', 'Pangasinan', 'Urdaneta', 'Catablan', 'N/A', 'Zone 5', '098', 2428, 'Pangasinan', 'Urdaneta', 'Catablan', 'N/A', 'Zone 5', '098', 2428),
(20220007, 'Benguet', 'Baguio', 'Poblacion', 'Benguet', 'Baguio', 'Ablong', 'N/A', 'Zone 5', '056', 74, 'Benguet', 'Baguio', 'Ablong', 'N/A', 'Zone 5', '056', 74),
(20220008, 'Pangasinan', 'Manaoag', 'Poblacion', 'Pangasinan', 'Manaoag', 'Poblacion', 'N/A', 'Zone 1', '076', 2430, 'Pangasinan', 'Manaoag', 'Poblacion', 'N/A', 'Zone 1', '076', 2430),
(20220009, 'Pangasinan', 'Urdaneta', 'Poblacion', 'Pangasinan', 'Urdaneta', 'Tulong', 'N/A', 'Zone 5', '0100', 2428, 'Pangasinan', 'Urdaneta', 'Tulong', 'N/A', 'Zone 5', '0100', 2428),
(20220010, 'Pangasinan', 'Binalonan', 'Poblacion', 'Pangasinan', 'Binalonan', 'Vacante', 'N/A', 'Zone 3', '110', 2436, 'Pangasinan', 'Binalonan', 'Vacante', 'N/A', 'Zone 3', '110', 2436);

-- --------------------------------------------------------

--
-- Table structure for table `student_education_bg`
--

CREATE TABLE `student_education_bg` (
  `id` int(10) NOT NULL,
  `elemtary_school` varchar(50) NOT NULL,
  `elemtary_school_poa` varchar(15) NOT NULL,
  `secondary_school` varchar(50) NOT NULL,
  `secondary_school_poa` varchar(15) NOT NULL,
  `course_school` varchar(50) NOT NULL,
  `course_school_poa` varchar(15) NOT NULL,
  `college` varchar(50) NOT NULL,
  `college_poa` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_education_bg`
--

INSERT INTO `student_education_bg` (`id`, `elemtary_school`, `elemtary_school_poa`, `secondary_school`, `secondary_school_poa`, `course_school`, `course_school_poa`, `college`, `college_poa`) VALUES
(20220001, 'Urdaneta City Elementary School', '2006-2012', 'Urdaneta City High School', '2012-2016', 'Urdaneta City High School', '2016-2018', 'Urdaneta City University', 'N/A'),
(20220002, 'Manaoag Elementary School', '20o6-2012', 'Manaoag Elementary School', '2012-2016', 'Manaoag Elementary School', '2016-2018', 'Urdaneta City University', 'N/A'),
(20220003, 'Manaoag Elementary School', '20o6-2012', 'Manaoag High School', '2012-2016', 'Manaoag High School', '2016-2018', 'Urdaneta City University', 'N/A'),
(20220004, 'Urdaneta Elementary School', '20o6-2012', 'Urdaneta High School', '2012-2016', 'Urdaneta High School', '2016-2018', 'Urdaneta City University', 'N/A'),
(20220005, 'Binalonan Elementary School', '20o6-2012', 'Binalonan High School', '2012-2016', 'Binalonan High School', '2016-2018', 'Urdaneta City University', 'N/A'),
(20220006, 'Urdaneta Elementary School', '20o6-2012', 'Urdaneta High School', '2012-2016', 'Urdaneta High School', '2016-2018', 'Urdaneta City University', 'N/A'),
(20220007, 'Baguio Elementary School', '20o6-2012', 'Baguio High School', '2012-2016', 'Baguio High School', '2016-2018', 'Urdaneta City University', 'N/A'),
(20220008, 'Manaoag Elementary School', '20o6-2012', 'Manaoag High School', '2012-2016', 'Manaoag High School', '2016-2018', 'Urdaneta City University', 'N/A'),
(20220009, 'Urdaneta Elementary School', '20o6-2012', 'Urdaneta High School', '2012-2016', 'Urdaneta High School', '2016-2018', 'Urdaneta City University', 'N/A'),
(20220010, 'Binalonan Elementary School', '20o6-2012', 'Binalonan High School', '2012-2016', 'Binalonan High School', '2016-2018', 'Urdaneta City University', 'N/A');

-- --------------------------------------------------------

--
-- Table structure for table `student_enroll`
--

CREATE TABLE `student_enroll` (
  `id` int(10) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `middle_name` varchar(50) NOT NULL,
  `suffix_name` varchar(10) NOT NULL,
  `password` varchar(50) NOT NULL,
  `block` int(10) NOT NULL,
  `school_year` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_enroll`
--

INSERT INTO `student_enroll` (`id`, `last_name`, `first_name`, `middle_name`, `suffix_name`, `password`, `block`, `school_year`) VALUES
(20220001, 'Brown', 'Brock', 'A.', '', 'password', 1, '2020-2021'),
(20220002, 'Johnson', 'Lenora', 'B.', '', 'password', 1, '2020-2021'),
(20220003, 'Williams', 'Willie', 'E.', '', 'password', 3, '2020-2021'),
(20220004, 'Smith', 'Garrett', 'D.', 'JR', 'password', 2, '2020-2021'),
(20220005, 'Davis', 'Alex', 'H.', '', 'password', 1, '2020-2021'),
(20220006, 'Garcia', 'Cathy', 'K.', 'III', 'password', 3, '2021-2022'),
(20220007, 'Miller', 'Felton', 'D.', '', 'password', 2, '2021-2022'),
(20220008, 'Martinez', 'Gregorio', 'E.', '', 'password', 1, '2021-2022'),
(20220009, 'Jones', 'Ophelia', 'I.', '', 'password', 1, '2021-2022'),
(20220010, 'Anderson', 'Cyrus', 'U.', 'JR', 'password', 2, '2021-2022'),
(20220011, 'Thomas', 'Simon', 'R.', '', 'password', 1, '2019-2020'),
(20220012, 'Jackson', 'Harriett', 'T', '', 'password', 3, '2019-2020'),
(20220013, 'Taylor', 'Lynne', 'U.', '', 'password', 2, '2019-2020'),
(20220014, 'Martin', 'Felicia', 'Y.', 'JR', 'password', 2, '2019-2020'),
(20220015, 'Wilson', 'Alonzo', 'D.', '', 'password', 1, '2019-2020'),
(20220016, 'Lopez', 'Garfield', 'D.', '', 'password', 3, '2018-2020'),
(20220017, 'Moore', 'Tristan', 'I.', '', 'password', 3, '2018-2020'),
(20220018, 'Lee', 'Nettie', 'A.', '', 'password', 2, '2018-2020'),
(20220019, 'Nelson', 'Cora', 'P.', 'IV', 'password', 1, '2018-2020'),
(20220020, 'Young', 'Beverley', 'R.', '', 'password', 1, '2018-2020');

-- --------------------------------------------------------

--
-- Table structure for table `student_family_bg`
--

CREATE TABLE `student_family_bg` (
  `id` int(10) NOT NULL,
  `spouse_surname` varchar(50) NOT NULL,
  `spouse_firstname` varchar(50) NOT NULL,
  `spouse_middlename` varchar(50) NOT NULL,
  `spouse_suffixname` varchar(10) NOT NULL,
  `spouse_occupation` varchar(20) NOT NULL,
  `spouse_employer_name` varchar(20) NOT NULL,
  `spouse_business_address` varchar(20) NOT NULL,
  `spouse_tel_no` varchar(20) NOT NULL,
  `spouse_mobile_no` varchar(20) NOT NULL,
  `father_surname` varchar(50) NOT NULL,
  `father_firstname` varchar(50) NOT NULL,
  `father_middlename` varchar(50) NOT NULL,
  `father_suffixname` varchar(10) NOT NULL,
  `father_occupation` varchar(20) NOT NULL,
  `father_mobile_no` varchar(20) NOT NULL,
  `mother_surname` varchar(50) NOT NULL,
  `mother_firstname` varchar(50) NOT NULL,
  `mother_middlename` varchar(50) NOT NULL,
  `mother_maidenname` varchar(50) NOT NULL,
  `mother_occupation` varchar(20) NOT NULL,
  `mother_mobile_no` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_family_bg`
--

INSERT INTO `student_family_bg` (`id`, `spouse_surname`, `spouse_firstname`, `spouse_middlename`, `spouse_suffixname`, `spouse_occupation`, `spouse_employer_name`, `spouse_business_address`, `spouse_tel_no`, `spouse_mobile_no`, `father_surname`, `father_firstname`, `father_middlename`, `father_suffixname`, `father_occupation`, `father_mobile_no`, `mother_surname`, `mother_firstname`, `mother_middlename`, `mother_maidenname`, `mother_occupation`, `mother_mobile_no`) VALUES
(20220001, 'N/A', 'N/A', 'N/A', ' ', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'Brown', 'Coffy', 'C.', 'Jr', 'office worker', '09000000000', 'Brown', 'Nes', 'D.', 'Sweet', 'OFW', '09000000000'),
(20220002, 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'Johnson', 'Jones', 'C.', ' ', 'LGU', '09000000000', 'Johnson', 'Mary', 'B.', 'Berney', 'OFW', '09000000000'),
(20220003, 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'Willie', 'Justin', 'B.', ' ', 'Teacher', '09000000000', 'Willie', 'Anne', 'A.', 'Edison', 'OFW', '09000000000'),
(20220004, 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'Smith', 'John', 'B.', ' ', 'Actor', '09000000000', 'Smith', 'Sophie', 'G.', 'De Vera', 'House Wife', '09000000000'),
(20220005, 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'Davis', 'Marlon', 'B.', ' ', 'OFW', '09000000000', 'Davis', 'Lexie', 'S.', 'Herson', 'N/A', '09000000000'),
(20220006, 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'Garcia', 'Gomez', 'H.', ' ', 'Farmer', '09000000000', 'Garcia', 'Tiffany', 'd.', 'Kamagon', 'online seller', '09000000000'),
(20220007, 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'Miller', 'Johnson', 'L.', ' ', 'Police', '09000000000', 'Miller', 'Carla', 'F.', 'Damazon', 'Cooker', '09000000000'),
(20220008, 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'Martinez', 'Manny', 'L.', ' ', 'Manager', '09000000000', 'Martinez', 'Marta', 'D.', 'Eglisia', 'Seller', '09000000000'),
(20220009, 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'Jones', 'Art', 'P.', ' ', 'doctor', '09000000000', 'Jones', 'stephanie', 'D.', 'Intro', 'House Keeping', '09000000000'),
(20220010, 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'Anderson', 'Cyrus', 'U.', 'Sr', 'Distributer', '09000000000', 'Anderson', 'Jenny', 'D.', 'Urdon', 'Seller', '09000000000');

-- --------------------------------------------------------

--
-- Table structure for table `student_infomation`
--

CREATE TABLE `student_infomation` (
  `id` int(10) NOT NULL,
  `surname` varchar(50) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `middlename` varchar(50) NOT NULL,
  `suffixname` varchar(10) NOT NULL,
  `birthday` date NOT NULL,
  `sex` varchar(10) NOT NULL,
  `civil_status` varchar(20) NOT NULL,
  `citizenship` varchar(20) NOT NULL,
  `blood_type` varchar(10) NOT NULL,
  `height` varchar(10) NOT NULL,
  `weight` varchar(10) NOT NULL,
  `tel_no` varchar(20) NOT NULL,
  `mobile_no` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `gsis_no` varchar(50) NOT NULL,
  `pagibig_no` varchar(50) NOT NULL,
  `philhealth_no` varchar(50) NOT NULL,
  `sss_no` varchar(50) NOT NULL,
  `employee_no` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_infomation`
--

INSERT INTO `student_infomation` (`id`, `surname`, `firstname`, `middlename`, `suffixname`, `birthday`, `sex`, `civil_status`, `citizenship`, `blood_type`, `height`, `weight`, `tel_no`, `mobile_no`, `email`, `gsis_no`, `pagibig_no`, `philhealth_no`, `sss_no`, `employee_no`) VALUES
(20220001, 'Brown', 'Brock', 'A.', ' ', '2000-01-01', 'Male', 'Single', 'filipino', 'A+', '1.70m', '45kg', '100-100', '09000000000', 'email@email.com', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A'),
(20220002, 'Johnson', 'Lenora', 'B.', ' ', '2013-04-10', 'Female', 'Single', 'filipino', 'O+', '1.50m', '49kg', 'N/A', '09000000000', 'email@email.com', 'N/A', 'N/A', '2931-1323-231', 'N/A', 'N/A'),
(20220003, 'Williams', 'Willie', 'E.', ' ', '2013-10-20', 'Male', 'Single', 'filipino', 'AB+', '1.69m', '52kg', 'N/A', '09000000000', 'email@email.com', 'N/A', 'N/A', '1234-9876-2312', 'N/A', 'N/A'),
(20220004, 'Smith', 'Garrett', 'D.', 'Jr', '2002-07-07', 'Male', 'Single', 'filipino', 'B+', '1.70m', '53kg', 'N/A', '09000000000', 'email@email.com', 'N/A', 'N/A', '4321-9876-4567', 'N/A', 'N/A'),
(20220005, 'Davis', 'Alex', 'H.', ' ', '2001-07-07', 'Male', 'Single', 'filipino', 'B+', '1.70m', '53kg', 'N/A', '09000000000', 'email@email.com', 'N/A', 'N/A', '4321-9876-4567', 'N/A', 'N/A'),
(20220006, 'Garcia', 'Cathy', 'K.', 'III', '2001-02-07', 'Female', 'Single', 'filipino', 'B+', '1.30m', '46kg', 'N/A', '09000000000', 'email@email.com', 'N/A', 'N/A', '8765-9876-4567', 'N/A', 'N/A'),
(20220007, 'Miller', 'Felton', 'D.', ' ', '2001-05-29', 'Male', 'Single', 'filipino', 'A+', '1.70m', '70kg', 'N/A', '09000000000', 'email@email.com', 'N/A', 'N/A', '1928-9876-4567', 'N/A', 'N/A'),
(20220008, 'Martinez', 'Gregorio', 'E.', ' ', '2001-10-29', 'Male', 'Single', 'filipino', 'O+', '1.67m', '67kg', 'N/A', '09000000000', 'email@email.com', 'N/A', 'N/A', '6758-9876-9875', 'N/A', 'N/A'),
(20220009, 'Jones', 'Opelia', '1.', ' ', '2000-11-30', 'Male', 'Single', 'filipino', 'O+', '1.67m', '77kg', 'N/A', '09000000000', 'email@email.com', 'N/A', 'N/A', '2378-9876-7643', 'N/A', 'N/A'),
(20220010, 'Anderson', 'Cyrus', 'U.', 'Jr', '2000-05-30', 'Male', 'Single', 'filipino', 'A-', '1.57m', '54kg', 'N/A', '09000000000', 'email@email.com', 'N/A', 'N/A', '2378-4808-3568', 'N/A', 'N/A');

-- --------------------------------------------------------

--
-- Table structure for table `student_station`
--

CREATE TABLE `student_station` (
  `id` int(11) NOT NULL,
  `s_id` int(11) NOT NULL,
  `sti_id` int(11) NOT NULL,
  `s_assign_date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_station`
--

INSERT INTO `student_station` (`id`, `s_id`, `sti_id`, `s_assign_date`) VALUES
(1, 20220001, 2, '2023-04-14'),
(2, 20220002, 12, '2023-04-14'),
(20220107, 20220003, 12, '2023-04-14'),
(20220108, 20220004, 2, '2023-04-14'),
(20220109, 20220005, 13, '2023-04-14'),
(20220110, 20220006, 2, '2023-04-14'),
(20220111, 20220007, 3, '2023-04-14'),
(20220112, 20220008, 12, '2023-04-14'),
(20220115, 20220010, 13, '2023-04-14'),
(20220116, 20220009, 2, '2023-04-26');

-- --------------------------------------------------------

--
-- Table structure for table `team_leader_student`
--

CREATE TABLE `team_leader_student` (
  `id` int(10) NOT NULL,
  `tl_id` int(10) NOT NULL,
  `sti_id` int(10) NOT NULL,
  `date_time` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `team_leader_student`
--

INSERT INTO `team_leader_student` (`id`, `tl_id`, `sti_id`, `date_time`) VALUES
(1, 20220001, 2, '2023-04-14 00:00:00'),
(3, 20220002, 11, '2023-04-14 00:00:00'),
(4, 20220005, 13, '2023-04-14 17:17:53'),
(5, 20220007, 3, '2023-04-14 17:20:52');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_db`
--
ALTER TABLE `admin_db`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`att_id`);

--
-- Indexes for table `cer_vac_db`
--
ALTER TABLE `cer_vac_db`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `message_db`
--
ALTER TABLE `message_db`
  ADD PRIMARY KEY (`message_id`);

--
-- Indexes for table `parent_con_db`
--
ALTER TABLE `parent_con_db`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `philhealth_id_db`
--
ALTER TABLE `philhealth_id_db`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `post_db`
--
ALTER TABLE `post_db`
  ADD PRIMARY KEY (`post_id`);

--
-- Indexes for table `pregnancy_db`
--
ALTER TABLE `pregnancy_db`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `station_info`
--
ALTER TABLE `station_info`
  ADD PRIMARY KEY (`sti_id`);

--
-- Indexes for table `student_address_bg`
--
ALTER TABLE `student_address_bg`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_education_bg`
--
ALTER TABLE `student_education_bg`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_enroll`
--
ALTER TABLE `student_enroll`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_family_bg`
--
ALTER TABLE `student_family_bg`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_infomation`
--
ALTER TABLE `student_infomation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_station`
--
ALTER TABLE `student_station`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `team_leader_student`
--
ALTER TABLE `team_leader_student`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tl_id` (`tl_id`,`sti_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_db`
--
ALTER TABLE `admin_db`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=98765433;

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `att_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `cer_vac_db`
--
ALTER TABLE `cer_vac_db`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `message_db`
--
ALTER TABLE `message_db`
  MODIFY `message_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `parent_con_db`
--
ALTER TABLE `parent_con_db`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `philhealth_id_db`
--
ALTER TABLE `philhealth_id_db`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `post_db`
--
ALTER TABLE `post_db`
  MODIFY `post_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `pregnancy_db`
--
ALTER TABLE `pregnancy_db`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `station_info`
--
ALTER TABLE `station_info`
  MODIFY `sti_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `student_address_bg`
--
ALTER TABLE `student_address_bg`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20220011;

--
-- AUTO_INCREMENT for table `student_education_bg`
--
ALTER TABLE `student_education_bg`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20220011;

--
-- AUTO_INCREMENT for table `student_enroll`
--
ALTER TABLE `student_enroll`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20220023;

--
-- AUTO_INCREMENT for table `student_family_bg`
--
ALTER TABLE `student_family_bg`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20220011;

--
-- AUTO_INCREMENT for table `student_infomation`
--
ALTER TABLE `student_infomation`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20220011;

--
-- AUTO_INCREMENT for table `student_station`
--
ALTER TABLE `student_station`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20220117;

--
-- AUTO_INCREMENT for table `team_leader_student`
--
ALTER TABLE `team_leader_student`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
